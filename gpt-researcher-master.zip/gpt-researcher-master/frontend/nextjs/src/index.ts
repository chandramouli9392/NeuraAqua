// src/index.ts
import { GPTResearcher } from './GPTResearcher';

export { GPTResearcher };
export type { GPTResearcherProps } from './GPTResearcher';